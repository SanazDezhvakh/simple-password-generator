import string
import secrets

# Function to generate password
def generate_password(length, include_special_chars):
    # Characters to use for the password
    chars = string.ascii_letters + string.digits  # Uppercase, lowercase letters and digits
    if include_special_chars:
        chars += string.punctuation  # Add special characters like @, #, $, etc.

    # Generate the password randomly from the available characters
    password = ''.join(secrets.choice(chars) for _ in range(length))
    
    return password

# Welcome message
print("** Password Generator Program **")
print("The password should include uppercase letters, lowercase letters, numbers, and optional special characters.")

# Ask the user for password length and if they want special characters
try:
    length = int(input("Enter the desired password length (e.g., 12): "))
    
    # Check to ensure that the password length is at least 1
    if length < 1:
        print("Password length must be at least 1.")
    else:
        include_special_chars = input("Do you want to include special characters? (y/n): ").lower() == 'y'

        # Generate the password
        password = generate_password(length, include_special_chars)

        # Show the generated password
        print("\nYour generated password:", password)

except ValueError:
    print("Please enter a valid number for the password length.")
